<?php
$type = 'text/css';
$files = array(
	'jquery.mobile.theme.css'
);
$base = dirname(__FILE__);
require_once('../../structure/index.php');
