<?php
$files = array_merge($files, array(
	'../../structure/jquery.mobile.core.css',
	'../../structure/jquery.mobile.transitions.css',
	'../../structure/jquery.mobile.grids.css',
	'../../structure/jquery.mobile.headerfooter.css',
	'../../structure/jquery.mobile.navbar.css',
	'../../structure/jquery.mobile.button.css',
	'../../structure/jquery.mobile.collapsible.css',
	'../../structure/jquery.mobile.controlgroup.css',
	'../../structure/jquery.mobile.dialog.css',
	'../../structure/jquery.mobile.forms.checkboxradio.css',
	'../../structure/jquery.mobile.forms.fieldcontain.css',
	'../../structure/jquery.mobile.forms.select.css',
	'../../structure/jquery.mobile.forms.textinput.css',
	'../../structure/jquery.mobile.listview.css',
	'../../structure/jquery.mobile.forms.slider.css'
));

require_once($base.'/../../../combine.php');

